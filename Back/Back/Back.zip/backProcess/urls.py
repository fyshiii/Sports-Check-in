from . import views as v
from django.urls import path
from django.urls import path
urlpatterns=[
    path("userLogin",v.login),
    path("lockTeacher",v.lockTeacher),
    path("getClass",v.getClass),
    path("delTeacher",v.delTeacher),
    path("getStudentData",v.getStudentData),
    path("getStudentList",v.getStudentList),
    path("lockStudent",v.lockStudent),
    path("delStudent",v.delStudent),
    path("getPoint",v.getPoint),
    path("setPoint",v.setPoint),
    path("getClassList",v.getclassList),
    path("getChart",v.getChart),
    path("getRecord",v.getRecord),
    path("getTeacherList",v.getTeacherList),
    path('getSchoolList',v.getSchoolList),
    path("setTeacherInfo",v.setTeacherInfo),
    path("setStudentInfo",v.setStudentInfo),
    path("upload_file",v.upload_file)
]